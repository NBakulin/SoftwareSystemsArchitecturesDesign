﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;


namespace objPool
{
    public class ObjectPool<T>
    {
        private ConcurrentBag<T> _objects;
        private Func<T> _objectGenerator;

        public ObjectPool(Func<T> objectGenerator)
        {
            if (objectGenerator == null) throw new ArgumentNullException("objectGenerator");
            _objects = new ConcurrentBag<T>();
            _objectGenerator = objectGenerator;
        }

        public T GetObject()
        {
            T item;
            if (_objects.TryTake(out item)) return item;
            return _objectGenerator();
        }

        public void PutObject(T item)
        {
            _objects.Add(item);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            CancellationTokenSource cts = new CancellationTokenSource();

            // Create an opportunity for the user to cancel.
            
            Task.Run(() =>
            {
                if (Console.ReadKey().KeyChar == 'c' || Console.ReadKey().KeyChar == 'C')
                    cts.Cancel();
            });

            ObjectPool<MyClassChickens> pool = new ObjectPool<MyClassChickens>(() => new MyClassChickens());

            // Create a high demand for MyClass objects.
            Parallel.For(0, 1000000, (i, loopState) =>
            {
                MyClassChickens mc = pool.GetObject();
                Console.CursorLeft = 0;
                // This is the bottleneck in our application. All threads in this loop
                // must serialize their access to the static Console class.
                if (mc.GetValue(i)==1)
                    Console.WriteLine("egg is taken", mc.GetValue(i));
                if (mc.GetValue(i) == 0) Console.WriteLine("your egg is under another chicken", mc.GetValue(i));

                pool.PutObject(mc);
                if (cts.Token.IsCancellationRequested)
                    loopState.Stop();

            });
            Console.WriteLine("Press the Enter key to exit the chicken house.");
            Console.ReadLine();
            cts.Dispose();
        }

    }

    
    class MyClassChickens
    {
        public double[] Eggs { get; set; }
        public double GetValue(long i)
        {
           // Console.WriteLine(Eggs[i]);
            return (Eggs[i]);
        }
        public MyClassChickens()
        {
            Eggs = new double[1000000];
            Random rand = new Random();
            for (int i = 0; i < Eggs.Length; i++)
                Eggs[i] = (int)Math.Round(rand.NextDouble());
            
        }
    }
}